"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const urls = {
    TON: "ton.com.br"
};
exports.default = urls;
